package Test;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW
}
