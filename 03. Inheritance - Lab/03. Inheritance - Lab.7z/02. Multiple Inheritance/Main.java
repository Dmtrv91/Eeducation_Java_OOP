
package Test;


public class Main {
    public static void main(String[] args) {

        Pyppy pyppy = new Pyppy();
        pyppy.eat();
        pyppy.bark();
        pyppy.weep();
    }
}
