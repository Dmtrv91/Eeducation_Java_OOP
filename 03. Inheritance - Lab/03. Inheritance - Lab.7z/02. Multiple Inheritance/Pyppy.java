package Test;

public class Pyppy extends Dog{
    public void weep(){
        System.out.println("weeping…");
    }
}
