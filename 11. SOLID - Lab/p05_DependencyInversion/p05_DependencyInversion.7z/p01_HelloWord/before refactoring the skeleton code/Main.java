package p05_DependencyInversion.p01_HelloWord;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
