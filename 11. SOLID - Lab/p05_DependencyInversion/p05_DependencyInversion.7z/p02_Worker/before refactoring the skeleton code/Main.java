package p05_DependencyInversion.p02_Worker;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
