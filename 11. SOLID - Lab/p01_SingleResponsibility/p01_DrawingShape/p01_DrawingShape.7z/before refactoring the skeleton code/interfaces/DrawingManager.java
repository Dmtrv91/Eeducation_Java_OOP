package p01_SingleResponsibility.p01_DrawingShape.interfaces;

public interface DrawingManager{
    void draw(Shape shape);
}
