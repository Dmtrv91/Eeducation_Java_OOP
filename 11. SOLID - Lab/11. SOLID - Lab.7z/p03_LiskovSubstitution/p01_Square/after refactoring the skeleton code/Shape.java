package p03_LiskovSubstitution.p01_Square;

public abstract class Shape {
    public abstract double getArea();


}
