package p01_SingleResponsibility.p01_DrawingShape;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
