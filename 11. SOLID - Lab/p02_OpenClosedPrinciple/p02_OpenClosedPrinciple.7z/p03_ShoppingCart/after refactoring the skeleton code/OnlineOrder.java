package p02_OpenClosedPrinciple.p03_ShoppingCart;

public class OnlineOrder extends Order {

    public OnlineOrder(Cart cart, String customerEmail) {
        super(cart, customerEmail);
    }
}
