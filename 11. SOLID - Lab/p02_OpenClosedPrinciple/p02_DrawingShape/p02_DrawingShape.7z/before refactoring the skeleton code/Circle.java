package p02_OpenClosedPrinciple.p02_DrawingShape;

import p02_OpenClosedPrinciple.p02_DrawingShape.interfaces.Shape;

public class Circle implements Shape {
}
