package interfaces;

public interface Person {
    String getName();

    String sayHello();
}
