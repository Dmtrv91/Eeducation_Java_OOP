package interfaces;

public interface Identifiable {

   String getId();
}
