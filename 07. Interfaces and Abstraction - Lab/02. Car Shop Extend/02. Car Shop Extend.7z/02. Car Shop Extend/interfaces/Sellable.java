package interfaces;

public interface Sellable {

    Double getPrice();
}
