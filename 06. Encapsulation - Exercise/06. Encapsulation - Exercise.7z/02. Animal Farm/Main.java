package Test;

import Test.chicken.Chicken;

import java.util.*;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Chicken chicken = new Chicken("koko", 10);

        System.out.println(chicken.toString());

    }
}







