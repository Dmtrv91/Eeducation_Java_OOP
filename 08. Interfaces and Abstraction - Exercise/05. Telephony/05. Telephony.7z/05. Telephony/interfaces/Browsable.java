package interfaces;

public interface Browsable {
    String call();
}
