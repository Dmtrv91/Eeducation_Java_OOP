package interfaces;

public interface Spy extends Soldier{
    Integer getCodeNumber();
}
