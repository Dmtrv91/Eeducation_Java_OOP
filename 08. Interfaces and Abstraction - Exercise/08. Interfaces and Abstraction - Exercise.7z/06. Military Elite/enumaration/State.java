package enumaration;


public enum State {
    inProgress,
    Finished,
}
