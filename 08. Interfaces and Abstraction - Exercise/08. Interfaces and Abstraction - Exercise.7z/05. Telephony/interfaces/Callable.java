package interfaces;

public interface Callable {

    String browse();
}
