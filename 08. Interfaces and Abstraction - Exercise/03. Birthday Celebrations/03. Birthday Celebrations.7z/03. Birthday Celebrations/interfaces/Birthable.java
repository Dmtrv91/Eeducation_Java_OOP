package interfaces;

public interface Birthable {

    String getBirthDate();
}
