package enumaration;

public enum Corp {
    Airforces,
    Marines,
}
