package interfaces;

public interface LeutenantGeneral extends Private{
    void addPrivate(Private priv);
}
