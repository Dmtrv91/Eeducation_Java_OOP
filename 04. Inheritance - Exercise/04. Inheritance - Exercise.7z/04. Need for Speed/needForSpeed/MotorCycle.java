package Test.needForSpeed;

public class MotorCycle extends Vehicle {
    public MotorCycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}
