package Test.needForSpeed;

public class CrossMotorcycle extends MotorCycle{
    public CrossMotorcycle(double fuel, int horsePower) {
        super(fuel, horsePower);
    }
}


