package interfaces;

public interface Vehicle {
    void drive(double distance);

    void refuel(double liters);

    void driveEmpty(double distance);
}
